from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from .forms import TaskForm
from .models import Task

def task_list(request):
    query = request.GET.get("q", "").strip()
    status = request.GET.get("status", "all")
    tasks = Task.objects.all()
    if query:
        tasks = tasks.filter(Q(title__icontains=query) | Q(description__icontains=query))
    if status == "open":
        tasks = tasks.filter(completed=False)
    elif status == "completed":
        tasks = tasks.filter(completed=True)
    return render(request, "taskmanager/task_list.html", {
        "tasks": tasks, "query": query, "status": status,
        "total_count": Task.objects.count(),
        "open_count": Task.objects.filter(completed=False).count(),
        "completed_count": Task.objects.filter(completed=True).count(),
    })

def task_create(request):
    if request.method == "POST":
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("task_list")
    else:
        form = TaskForm()
    return render(request, "taskmanager/task_form.html", {"form": form, "page_title": "Add a task"})

def task_edit(request, pk):
    task = get_object_or_404(Task, pk=pk)
    if request.method == "POST":
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect("task_list")
    else:
        form = TaskForm(instance=task)
    return render(request, "taskmanager/task_form.html", {"form": form, "page_title": "Edit task"})

def task_toggle(request, pk):
    task = get_object_or_404(Task, pk=pk)
    if request.method == "POST":
        task.completed = not task.completed
        task.save(update_fields=["completed"])
    return redirect("task_list")

def task_delete(request, pk):
    task = get_object_or_404(Task, pk=pk)
    if request.method == "POST":
        task.delete()
        return redirect("task_list")
    return redirect("task_list")
